export const COLOR_1 = '#86A8E7';
export const COLOR_2 = '#91EAE4';
